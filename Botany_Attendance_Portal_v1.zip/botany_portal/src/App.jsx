import { useEffect, useMemo, useState } from 'react';
import { isSupabaseConfigured, supabase } from './supabase';

const demoSubjects = [
  { id: 'bot-001', code: '213001', name: 'Microbiology' },
  { id: 'bot-003', code: '213003', name: 'Mycology' },
  { id: 'bot-005', code: '213005', name: 'Phycology' },
  { id: 'bot-007', code: '213007', name: 'Plant Anatomy' },
];
const demoNotices = [
  { id: 'n1', title: 'Botany Department Portal-এ স্বাগতম', body: 'এটি নতুন Attendance + Academic Portal-এর প্রাথমিক ডেমো। প্রকাশিত নোটিশ ও রুটিন Supabase যুক্ত হলে লাইভ ডেটা থেকে দেখানো হবে।', created_at: new Date().toISOString() },
  { id: 'n2', title: 'উপস্থিতির তথ্য যাচাই', body: 'উপস্থিতির রেকর্ডে ভুল দেখলে সংশ্লিষ্ট শিক্ষক বা বিভাগীয় অ্যাডমিনের সঙ্গে যোগাযোগ করো।', created_at: new Date(Date.now() - 86400000).toISOString() },
];
const bn = (v) => String(v ?? '').replace(/\d/g, d => '০১২৩৪৫৬৭৮৯'[d]);
const pct = (a, t) => t ? Math.round((a / t) * 1000) / 10 : 0;

function LeafMark() { return <span className="leaf-mark" aria-hidden="true">❧</span>; }
function App() {
  const [session, setSession] = useState(null);
  const [isDemo, setIsDemo] = useState(false);
  const [profile, setProfile] = useState(null);
  const [page, setPage] = useState('overview');
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [authMode, setAuthMode] = useState('login');
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authName, setAuthName] = useState('');
  const [attendance, setAttendance] = useState([]);
  const [notices, setNotices] = useState(demoNotices);
  const [subjects, setSubjects] = useState(demoSubjects);
  const [routines, setRoutines] = useState([]);
  const [resources, setResources] = useState([]);
  const [students, setStudents] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [selectedSubject, setSelectedSubject] = useState(demoSubjects[0].id);
  const [classDate, setClassDate] = useState(new Date().toISOString().slice(0, 10));
  const [sessionTitle, setSessionTitle] = useState('Regular Class');
  const [marks, setMarks] = useState({});
  const [calculator, setCalculator] = useState({ total: 70, held: 35, attended: '' });
  const [calcResult, setCalcResult] = useState(null);
  const role = profile?.role || 'student';
  const isStaff = role === 'teacher' || role === 'admin';

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => setSession(nextSession));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!session || !supabase) { setProfile(null); return; }
    let alive = true;
    (async () => {
      const { data, error } = await supabase.from('profiles').select('id, full_name, email, role, student_id, department').eq('id', session.user.id).maybeSingle();
      if (!alive) return;
      if (error) setNotice('প্রোফাইল লোড করা যায়নি: ' + error.message);
      setProfile(data || { id: session.user.id, email: session.user.email, full_name: session.user.user_metadata?.full_name || 'ব্যবহারকারী', role: 'student' });
    })();
    return () => { alive = false; };
  }, [session]);

  useEffect(() => {
    if (!session || !supabase || !profile) return;
    loadPortalData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session, profile?.id, profile?.role]);

  async function loadPortalData() {
    if (!supabase) return;
    const [subRes, noticeRes, routineRes, resourceRes, attendanceRes, sessionRes] = await Promise.all([
      supabase.from('subjects').select('*').order('code'),
      supabase.from('notices').select('*').eq('published', true).order('created_at', { ascending: false }).limit(10),
      supabase.from('routines').select('*').eq('published', true).order('class_date'),
      supabase.from('resources').select('*').eq('published', true).order('created_at', { ascending: false }),
      supabase.from('attendance_records').select('id,status,student_id,attendance_sessions(id,subject_id,class_date,title,subjects(code,name))').order('created_at', { ascending: false }).limit(200),
      supabase.from('attendance_sessions').select('id,subject_id,class_date,title,subjects(code,name)').order('class_date', { ascending: false }).limit(100),
    ]);
    if (subRes.data?.length) setSubjects(subRes.data);
    if (noticeRes.data) setNotices(noticeRes.data);
    if (routineRes.data) setRoutines(routineRes.data);
    if (resourceRes.data) setResources(resourceRes.data);
    if (attendanceRes.data) setAttendance(attendanceRes.data);
    if (sessionRes.data) setSessions(sessionRes.data);
    if (profile?.role === 'teacher' || profile?.role === 'admin') {
      const { data, error } = await supabase.from('profiles').select('id,full_name,email,student_id').eq('role', 'student').order('full_name');
      if (data) setStudents(data);
      if (error) setNotice('শিক্ষার্থী তালিকা লোড হয়নি। SQL/RLS সেটআপ যাচাই করো।');
    }
  }

  async function submitAuth(e) {
    e.preventDefault(); setBusy(true); setNotice('');
    try {
      if (!supabase) { setNotice('Supabase এখনও কনফিগার করা হয়নি। .env.local ফাইলে URL ও publishable/anon key যোগ করো।'); return; }
      if (authMode === 'signup') {
        const { error } = await supabase.auth.signUp({ email: authEmail, password: authPassword, options: { data: { full_name: authName } } });
        if (error) throw error;
        setNotice('অ্যাকাউন্ট অনুরোধ তৈরি হয়েছে। ইমেইল কনফার্মেশন চালু থাকলে ইনবক্স যাচাই করো।');
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email: authEmail, password: authPassword });
        if (error) throw error;
      }
    } catch (err) { setNotice(err.message || 'লগইন করা যায়নি।'); }
    finally { setBusy(false); }
  }
  function enterDemo() { setIsDemo(true); setProfile({ id: 'demo-student', full_name: 'ডেমো শিক্ষার্থী', email: 'student@example.test', role: 'student', student_id: 'DEMO-001', department: 'Botany' }); setAttendance([{id:'demo-a1',student_id:'demo-student',status:'present',attendance_sessions:{class_date:new Date().toISOString().slice(0,10),title:'Regular Class',subjects:{code:'213001',name:'Microbiology'}}},{id:'demo-a2',student_id:'demo-student',status:'present',attendance_sessions:{class_date:new Date(Date.now()-86400000*2).toISOString().slice(0,10),title:'Lecture',subjects:{code:'213003',name:'Mycology'}}},{id:'demo-a3',student_id:'demo-student',status:'absent',attendance_sessions:{class_date:new Date(Date.now()-86400000*4).toISOString().slice(0,10),title:'Practical',subjects:{code:'213005',name:'Phycology'}}}]); setPage('overview'); setNotice('ডেমো মোড: এখানে কোনো বাস্তব তথ্য সংরক্ষণ করা হচ্ছে না।'); }
  async function signOut() { if (supabase) await supabase.auth.signOut(); setSession(null); setProfile(null); setIsDemo(false); setPage('overview'); }

  async function saveAttendance() {
    if (!supabase || !isStaff) { setNotice('উপস্থিতি সংরক্ষণের জন্য শিক্ষক/অ্যাডমিন লগইন ও Supabase কনফিগারেশন প্রয়োজন।'); return; }
    if (!students.length) { setNotice('কোনো শিক্ষার্থী পাওয়া যায়নি। আগে profiles-এ শিক্ষার্থী অ্যাকাউন্ট তৈরি করো।'); return; }
    setBusy(true); setNotice('');
    try {
      const { data: newSession, error: sessionError } = await supabase.from('attendance_sessions').insert({ subject_id: selectedSubject, class_date: classDate, title: sessionTitle, created_by: session.user.id }).select('id').single();
      if (sessionError) throw sessionError;
      const rows = students.map(s => ({ session_id: newSession.id, student_id: s.id, status: marks[s.id] || 'present', marked_by: session.user.id }));
      const { error } = await supabase.from('attendance_records').insert(rows);
      if (error) throw error;
      setNotice('উপস্থিতি সফলভাবে সংরক্ষিত হয়েছে।'); setMarks({}); await loadPortalData();
    } catch (err) { setNotice('সংরক্ষণ করা যায়নি: ' + err.message + ' — কোনো session তৈরি হয়ে থাকলে teacher/admin সেটি যাচাই করুন।'); }
    finally { setBusy(false); }
  }

  async function addNotice(e) {
    e.preventDefault(); const fd = new FormData(e.currentTarget);
    if (!supabase || !isStaff) { setNotice('নোটিশ প্রকাশ করতে Supabase-এ শিক্ষক/অ্যাডমিন হিসেবে লগইন করো।'); return; }
    setBusy(true);
    const { error } = await supabase.from('notices').insert({ title: fd.get('title'), body: fd.get('body'), published: fd.get('published') === 'on', created_by: session.user.id });
    setBusy(false); if (error) setNotice(error.message); else { setNotice('নোটিশ সংরক্ষিত হয়েছে।'); e.currentTarget.reset(); await loadPortalData(); }
  }

  const myAttendance = useMemo(() => attendance.filter(r => isStaff || r.student_id === profile?.id), [attendance, isStaff, profile?.id]);
  const presentCount = myAttendance.filter(r => r.status === 'present').length;
  const attendancePct = pct(presentCount, myAttendance.length);
  const upcoming = routines.filter(r => r.class_date >= new Date().toISOString().slice(0, 10)).slice(0, 4);

  function runCalculator(e) {
    e.preventDefault();
    const total = Math.max(1, Number(calculator.total)); const held = Math.max(0, Math.min(total, Number(calculator.held))); const attended = Number(calculator.attended);
    if (calculator.attended === '' || !Number.isFinite(attended) || attended < 0 || attended > held) { setCalcResult({ error: 'উপস্থিত ক্লাসের সংখ্যা ০ থেকে অনুষ্ঠিত ক্লাসের মধ্যে হতে হবে।' }); return; }
    const remaining = total - held; const current = pct(attended, held);
    const target = (rate) => { const need = Math.max(0, Math.ceil(total * rate) - attended); return { need, possible: need <= remaining, reached: attended >= Math.ceil(total * rate) }; };
    setCalcResult({ total, held, attended, remaining, missed: held - attended, current, t60: target(.6), t70: target(.7) });
  }

  if (!session && !isDemo) return <AuthScreen {...{ authMode, setAuthMode, authEmail, setAuthEmail, authPassword, setAuthPassword, authName, setAuthName, submitAuth, busy, notice, onDemo: enterDemo }} />;

  const nav = [
    ['overview', '◈', 'ড্যাশবোর্ড'], ['attendance', '▦', 'আমার উপস্থিতি'], ['routine', '▤', 'ক্লাস ও পরীক্ষা রুটিন'], ['notices', '◉', 'নোটিশ বোর্ড'], ['resources', '▧', 'স্টাডি রিসোর্স'],
    ...(isStaff ? [['take', '＋', 'উপস্থিতি নাও'], ['students', '♧', 'শিক্ষার্থী তালিকা'], ['manage', '⚙', 'কনটেন্ট ম্যানেজমেন্ট']] : []),
    ['calculator', '％', 'অ্যাটেনডেন্স ক্যালকুলেটর'],
  ];

  return <div className="app-shell"><aside className="sidebar"><div className="brand"><div className="brand-icon"><LeafMark /></div><div><b>BOTANY<span>PORTAL</span></b><small>GHMMC · Chattogram</small></div></div><div className="side-caption">WORKSPACE</div><nav className="side-nav">{nav.map(([id, icon, label]) => <button key={id} className={page === id ? 'nav-item active' : 'nav-item'} onClick={() => setPage(id)}><span>{icon}</span>{label}</button>)}</nav><div className="sidebar-bottom"><div className="online-dot" /> {isSupabaseConfigured ? 'Supabase সংযুক্ত' : 'ডেমো / কনফিগারেশন বাকি'}<small>Department of Botany</small></div></aside>
    <main className="main-area"><header className="topbar"><div><div className="eyebrow">GOVT. HAJI MUHAMMAD MOHSIN COLLEGE</div><h1>{nav.find(n => n[0] === page)?.[2] || 'ড্যাশবোর্ড'}</h1></div><div className="user-area"><div className="avatar">{(profile?.full_name || 'শি').slice(0, 1)}</div><div className="user-meta"><b>{profile?.full_name || session.user.email}</b><small>{role === 'admin' ? 'অ্যাডমিন' : role === 'teacher' ? 'শিক্ষক' : 'শিক্ষার্থী'}</small></div><button className="icon-btn" title="লগআউট" onClick={signOut}>↗</button></div></header>
    {notice && <div className="notice-banner" role="status"><span>ⓘ {notice}</span><button onClick={() => setNotice('')}>×</button></div>}
    {page === 'overview' && <><section className="welcome-panel"><div><div className="welcome-tag"><span /> YOUR ACADEMIC SPACE</div><h2>স্বাগতম, {profile?.full_name?.split(' ')[0] || 'শিক্ষার্থী'} 🌱</h2><p>তোমার একাডেমিক অগ্রগতি, উপস্থিতি ও বিভাগের আপডেট এক জায়গায়।</p></div><div className="plant-art">❧</div></section><section className="stat-grid"><Stat icon="◷" label="উপস্থিতির হার" value={myAttendance.length ? `${bn(attendancePct)}%` : '—'} note="রেকর্ড পাওয়া গেলে হিসাব হবে"/><Stat icon="▦" label="রেকর্ডকৃত ক্লাস" value={bn(myAttendance.length)} note="তোমার অ্যাক্সেস অনুযায়ী"/><Stat icon="◉" label="প্রকাশিত নোটিশ" value={bn(notices.length)} note="সাম্প্রতিক আপডেট"/><Stat icon="▤" label="স্টাডি রিসোর্স" value={bn(resources.length)} note="প্রকাশিত উপকরণ"/></section><section className="content-grid"><div className="panel"><PanelHeading title="সাম্প্রতিক নোটিশ" action="সব নোটিশ দেখো" onAction={() => setPage('notices')}/>{notices.slice(0, 3).map(n => <NoticeRow key={n.id} item={n}/>)}{!notices.length && <Empty text="এখনও কোনো নোটিশ প্রকাশিত হয়নি।"/>}</div><div className="panel"><PanelHeading title="আসন্ন ক্লাস" action="রুটিন দেখো" onAction={() => setPage('routine')}/>{upcoming.map(r => <div className="routine-row" key={r.id}><div className="date-tile"><b>{bn(new Date(r.class_date + 'T00:00:00').getDate())}</b><small>{new Date(r.class_date + 'T00:00:00').toLocaleDateString('en-US',{month:'short'})}</small></div><div><b>{r.title || 'ক্লাস'}</b><small>{r.start_time || 'সময় নির্ধারিত নয়'} · {r.room || 'কক্ষ নির্ধারিত নয়'}</small></div></div>)}{!upcoming.length && <Empty text="রুটিন এখনও প্রকাশিত হয়নি।"/>}</div></section></>}
    {page === 'attendance' && <section className="panel page-panel"><PanelHeading title={isStaff ? 'সাম্প্রতিক উপস্থিতির রেকর্ড' : 'আমার উপস্থিতির রেকর্ড'}/><div className="attendance-summary"><div><small>রেকর্ড</small><b>{bn(myAttendance.length)}</b></div><div><small>উপস্থিত</small><b>{bn(presentCount)}</b></div><div><small>উপস্থিতির হার</small><b>{myAttendance.length ? bn(attendancePct) + '%' : '—'}</b></div></div><div className="table-wrap"><table><thead><tr><th>তারিখ</th><th>বিষয়</th><th>ক্লাস</th><th>অবস্থা</th></tr></thead><tbody>{myAttendance.map(r => <tr key={r.id}><td>{r.attendance_sessions?.class_date || '—'}</td><td>{r.attendance_sessions?.subjects?.name || 'বিষয়'}</td><td>{r.attendance_sessions?.title || 'নিয়মিত ক্লাস'}</td><td><span className={'status '+r.status}>{statusBn(r.status)}</span></td></tr>)}</tbody></table></div>{!myAttendance.length && <Empty text={isSupabaseConfigured ? 'এই অ্যাকাউন্টের জন্য উপস্থিতির রেকর্ড পাওয়া যায়নি।' : 'Supabase যুক্ত করলে ব্যক্তিগত উপস্থিতির তথ্য এখানে দেখা যাবে।'}/>}</section>}
    {page === 'routine' && <section className="panel page-panel"><PanelHeading title="ক্লাস ও পরীক্ষা রুটিন"/><div className="routine-list">{routines.map(r => <div className="routine-full" key={r.id}><div className="date-tile"><b>{bn(new Date(r.class_date + 'T00:00:00').getDate())}</b><small>{new Date(r.class_date + 'T00:00:00').toLocaleDateString('en-US',{month:'short'})}</small></div><div className="grow"><b>{r.title}</b><small>{r.subject_name || r.subjects?.name || 'বিভাগীয় কার্যক্রম'} · {r.room || 'কক্ষ উল্লেখ নেই'}</small></div><span className="soft-pill">{r.start_time || 'সময় ঘোষণা হয়নি'}</span></div>)}{!routines.length && <Empty text="প্রকাশিত রুটিন নেই। শিক্ষক/অ্যাডমিন কনটেন্ট ম্যানেজমেন্ট থেকে রুটিন যুক্ত করতে পারবেন (SQL সেটআপ অনুযায়ী)।"/>}</div></section>}
    {page === 'notices' && <section className="panel page-panel"><PanelHeading title="বিভাগীয় নোটিশ বোর্ড"/><div className="notice-list">{notices.map(n => <NoticeRow key={n.id} item={n} expanded/>)}{!notices.length && <Empty text="কোনো প্রকাশিত নোটিশ নেই।"/>}</div></section>}
    {page === 'resources' && <section className="panel page-panel"><PanelHeading title="স্টাডি রিসোর্স"/><div className="resource-grid">{resources.map(r => <a className="resource-card" href={r.url} target="_blank" rel="noreferrer" key={r.id}><span className="resource-icon">▧</span><b>{r.title}</b><small>{r.description || 'বিভাগীয় শিক্ষাসামগ্রী'}</small><span className="resource-link">রিসোর্স দেখো ↗</span></a>)}</div>{!resources.length && <Empty text="এখনও কোনো রিসোর্স প্রকাশিত হয়নি।"/>}</section>}
    {page === 'take' && isStaff && <section className="panel page-panel"><PanelHeading title="আজকের উপস্থিতি নাও"/><p className="muted paragraph">তারিখ ও বিষয় নির্বাচন করে শিক্ষার্থীদের উপস্থিতি চিহ্নিত করো। সংরক্ষণের আগে তালিকাটি যাচাই করো।</p><div className="form-grid"><label>বিষয়<select value={selectedSubject} onChange={e => setSelectedSubject(e.target.value)}>{subjects.map(s => <option key={s.id} value={s.id}>{s.code} — {s.name}</option>)}</select></label><label>ক্লাসের তারিখ<input type="date" value={classDate} onChange={e => setClassDate(e.target.value)}/></label><label className="span-two">ক্লাসের শিরোনাম<input value={sessionTitle} onChange={e => setSessionTitle(e.target.value)} placeholder="যেমন: Practical class"/></label></div><div className="table-wrap"><table><thead><tr><th>শিক্ষার্থী</th><th>আইডি / ইমেইল</th><th>উপস্থিতি</th></tr></thead><tbody>{students.map(s => <tr key={s.id}><td>{s.full_name || 'নাম নেই'}</td><td>{s.student_id || s.email || '—'}</td><td><select className="status-select" value={marks[s.id] || 'present'} onChange={e => setMarks(m => ({...m,[s.id]:e.target.value}))}><option value="present">উপস্থিত</option><option value="absent">অনুপস্থিত</option><option value="leave">ছুটি</option></select></td></tr>)}</tbody></table></div>{!students.length && <Empty text="শিক্ষার্থী তালিকা লোড হয়নি। Supabase schema চালিয়ে student profile তৈরি করো।"/>}<div className="form-actions"><button className="primary-btn" disabled={busy || !students.length} onClick={saveAttendance}>{busy ? 'সংরক্ষণ হচ্ছে…' : 'উপস্থিতি সংরক্ষণ করো'}</button></div></section>}
    {page === 'students' && isStaff && <section className="panel page-panel"><PanelHeading title="শিক্ষার্থী তালিকা"/><div className="table-wrap"><table><thead><tr><th>নাম</th><th>শিক্ষার্থী আইডি</th><th>ইমেইল</th></tr></thead><tbody>{students.map(s => <tr key={s.id}><td>{s.full_name || '—'}</td><td>{s.student_id || '—'}</td><td>{s.email || '—'}</td></tr>)}</tbody></table></div>{!students.length && <Empty text="শিক্ষার্থী ডেটা এখানে দেখা যাবে।"/>}</section>}
    {page === 'manage' && isStaff && <section className="panel page-panel"><PanelHeading title="কনটেন্ট ম্যানেজমেন্ট"/><p className="muted paragraph">নোটিশ প্রকাশের ফর্মটি কার্যকর। রুটিন ও রিসোর্সের ব্যবস্থাপনা পরবর্তী iteration-এ যোগ করা যাবে।</p><form className="stack-form" onSubmit={addNotice}><label>নোটিশের শিরোনাম<input name="title" required maxLength="160" placeholder="নোটিশের শিরোনাম"/></label><label>বিস্তারিত<textarea name="body" required rows="4" placeholder="নোটিশের বিস্তারিত লিখো"/></label><label className="check-label"><input type="checkbox" name="published" defaultChecked/> সঙ্গে সঙ্গে প্রকাশ করো</label><button className="primary-btn" disabled={busy}>{busy ? 'সংরক্ষণ হচ্ছে…' : 'নোটিশ সংরক্ষণ করো'}</button></form></section>}
    {page === 'calculator' && <section className="panel page-panel"><PanelHeading title="অ্যাটেনডেন্স ক্যালকুলেটর"/><p className="muted paragraph">এটি ব্যক্তিগত হিসাবের টুল। এটি নিজে থেকে অফিসিয়াল উপস্থিতির রেকর্ড পরিবর্তন করে না।</p><form className="form-grid" onSubmit={runCalculator}><label>মোট নির্ধারিত ক্লাস<input type="number" min="1" required value={calculator.total} onChange={e => setCalculator({...calculator,total:e.target.value})}/></label><label>এখন পর্যন্ত অনুষ্ঠিত ক্লাস<input type="number" min="0" required value={calculator.held} onChange={e => setCalculator({...calculator,held:e.target.value})}/></label><label className="span-two">তুমি কতটি ক্লাসে উপস্থিত ছিলে?<input type="number" min="0" required value={calculator.attended} onChange={e => setCalculator({...calculator,attended:e.target.value})} placeholder="উপস্থিত ক্লাসের সংখ্যা"/></label><div className="span-two"><button className="primary-btn">হিসাব করো</button></div></form>{calcResult && (calcResult.error ? <p className="error-text">{calcResult.error}</p> : <div className="calc-output"><div className="attendance-summary"><div><small>বর্তমান উপস্থিতি</small><b>{bn(calcResult.current)}%</b></div><div><small>অনুপস্থিত</small><b>{bn(calcResult.missed)}</b></div><div><small>বাকি ক্লাস</small><b>{bn(calcResult.remaining)}</b></div></div><div className="target-grid">{[['৬০%',calcResult.t60],['৭০%',calcResult.t70]].map(([label,t])=><div className="target-box" key={label}><small>লক্ষ্যমাত্রা {label}</small><b>{t.reached?'লক্ষ্য পূরণ হয়েছে':t.possible?`আরও ${bn(t.need)} ক্লাসে উপস্থিত থাকতে হবে`:'লক্ষ্য পূরণ সম্ভব নয়'}</b></div>)}</div></div>)}</section>}
    <footer className="app-footer">Department of Botany · Govt. Hazi Muhammad Mohsin College <span>Built for learning & growth <LeafMark /></span></footer></main></div>;
}

function AuthScreen(p) { return <div className="auth-page"><div className="auth-orb orb-one"/><div className="auth-orb orb-two"/><div className="auth-card"><div className="auth-brand"><div className="brand-icon"><LeafMark/></div><div><b>BOTANY<span>PORTAL</span></b><small>GHMMC · Chattogram</small></div></div><div className="welcome-tag"><span/> DEPARTMENT ACADEMIC PORTAL</div><h1>{p.authMode === 'login' ? 'আবার স্বাগতম' : 'অ্যাকাউন্ট তৈরি করো'}</h1><p className="muted">উপস্থিতি, রুটিন, নোটিশ ও পড়াশোনার উপকরণ—এক জায়গায়।</p>{!isSupabaseConfigured && <div className="setup-hint"><b>প্রথমবার সেটআপ</b><br/>Supabase URL ও publishable/anon key `.env.local`-এ যোগ করলে লগইন সক্রিয় হবে।</div>}<form className="stack-form auth-form" onSubmit={p.submitAuth}>{p.authMode === 'signup' && <label>পূর্ণ নাম<input value={p.authName} onChange={e=>p.setAuthName(e.target.value)} required placeholder="তোমার নাম" autoComplete="name"/></label>}<label>ইমেইল<input type="email" value={p.authEmail} onChange={e=>p.setAuthEmail(e.target.value)} required placeholder="you@example.com" autoComplete="email"/></label><label>পাসওয়ার্ড<input type="password" value={p.authPassword} onChange={e=>p.setAuthPassword(e.target.value)} minLength="8" required placeholder="কমপক্ষে ৮ অক্ষর" autoComplete={p.authMode==='login'?'current-password':'new-password'}/></label><button className="primary-btn auth-submit" disabled={p.busy}>{p.busy?'অপেক্ষা করো…':p.authMode==='login'?'নিরাপদে লগইন করো →':'অ্যাকাউন্ট তৈরি করো →'}</button></form>{p.notice && <div className="notice-banner">{p.notice}</div>}<div className="auth-switch">{p.authMode==='login'?'নতুন ব্যবহারকারী?':'আগে অ্যাকাউন্ট আছে?'} <button onClick={()=>p.setAuthMode(p.authMode==='login'?'signup':'login')}>{p.authMode==='login'?'অ্যাকাউন্ট তৈরি করো':'লগইন করো'}</button></div><button type="button" className="demo-btn" onClick={p.onDemo}>ডেমো ড্যাশবোর্ড দেখো ↗</button><small className="auth-foot">🔒 নিরাপদ অ্যাক্সেস · Botany Department only</small></div></div>; }
function Stat({icon,label,value,note}) { return <div className="stat-card"><div className="stat-top"><span className="stat-icon">{icon}</span><span className="stat-indicator">↗</span></div><div className="stat-value">{value}</div><div className="stat-label">{label}</div><div className="stat-note">{note}</div></div>; }
function PanelHeading({title,action,onAction}) { return <div className="panel-heading"><h3>{title}</h3>{action && <button onClick={onAction}>{action} ↗</button>}</div>; }
function NoticeRow({item,expanded=false}) { return <article className="notice-row"><div className="notice-mark">◉</div><div className="notice-copy"><b>{item.title}</b><p className={expanded?'':'clamp-two'}>{item.body}</p><small>{item.created_at ? new Date(item.created_at).toLocaleDateString('bn-BD',{day:'numeric',month:'short',year:'numeric'}) : ''}</small></div></article>; }
function Empty({text}) { return <div className="empty-state"><span>❧</span><p>{text}</p></div>; }
function statusBn(s) { return ({present:'উপস্থিত',absent:'অনুপস্থিত',leave:'ছুটি'})[s] || s; }
export default App;
