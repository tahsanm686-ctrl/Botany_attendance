# Botany Attendance + Academic Portal (GHMMC)

A React + Vite starter rebuilt from the uploaded single-file `index.html`, keeping its botanical green look while adding a role-aware academic portal shell and Supabase integration points.

## Included
- Email/password sign-in and sign-up through Supabase Auth
- Profile roles: `student`, `teacher`, `admin` (sign-ups are always students)
- Student-scoped attendance views; staff attendance-taking interface
- Notices, class/exam routine and study resources views
- Personal attendance calculator with corrected current-rate formula (`attended / held classes`)
- Supabase SQL schema with Row Level Security policies
- `.env.example` only; no real keys or student data included

## Local development
1. Install Node.js 20+.
2. Copy `.env.example` to `.env.local`.
3. Create a Supabase project and set `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` in `.env.local`.
4. In Supabase SQL Editor, review and run `supabase/schema.sql`.
5. Run `npm install`, then `npm run dev`.
6. Build check with `npm run build`.

The app intentionally does not include a service-role key. A browser publishable/anon key is acceptable only with RLS enabled and carefully reviewed policies.

## Staff account setup
1. Sign up through the portal.
2. Verify the profile exists in `public.profiles`.
3. As project owner, promote a trusted faculty profile using the commented SQL at the bottom of `supabase/schema.sql`.
4. Add students using sign-up, then assign subject enrollments as appropriate.

Never allow a client-side form or user metadata to assign `teacher` or `admin` roles.

## Important before production
- Review and test RLS policies in a non-production Supabase project.
- Configure email confirmation, password recovery, allowed redirect URLs, and rate limits.
- Add enrolment-aware validation to attendance-taking and implement audit-log writes for corrections.
- Add complete create/edit/delete screens for routines and resources.
- Decide how to handle class-session partial failures; the attendance save UI currently reports errors but does not automatically roll back an already-created session.
- Back up existing production data before any migration. This starter does not connect to or modify an existing live project until environment variables are supplied.

## Deploy to Vercel
Import the repository into Vercel, set the two environment variables in Project Settings, and deploy. Framework preset: Vite. Build command: `npm run build`; output directory: `dist`.
