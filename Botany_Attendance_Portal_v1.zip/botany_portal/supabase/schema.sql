-- GHMMC Botany Attendance + Academic Portal
-- Run in Supabase SQL Editor using a trusted project owner account.
-- New signups are always students. Promote staff manually using the SQL below.

create extension if not exists pgcrypto;

do $$ begin
  create type public.app_role as enum ('student', 'teacher', 'admin');
exception when duplicate_object then null; end $$;
do $$ begin
  create type public.attendance_status as enum ('present', 'absent', 'leave');
exception when duplicate_object then null; end $$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  email text,
  role public.app_role not null default 'student',
  student_id text unique,
  department text not null default 'Botany',
  created_at timestamptz not null default now()
);
create table if not exists public.subjects (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  semester text,
  credits numeric(3,1),
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create table if not exists public.enrollments (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.profiles(id) on delete cascade,
  subject_id uuid not null references public.subjects(id) on delete cascade,
  academic_session text,
  created_at timestamptz not null default now(),
  unique(student_id, subject_id, academic_session)
);
create table if not exists public.attendance_sessions (
  id uuid primary key default gen_random_uuid(),
  subject_id uuid not null references public.subjects(id) on delete restrict,
  class_date date not null,
  title text not null default 'Regular Class',
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);
create table if not exists public.attendance_records (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references public.attendance_sessions(id) on delete cascade,
  student_id uuid not null references public.profiles(id) on delete cascade,
  status public.attendance_status not null default 'present',
  marked_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(session_id, student_id)
);
create table if not exists public.notices (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null,
  published boolean not null default false,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);
create table if not exists public.routines (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  subject_id uuid references public.subjects(id) on delete set null,
  class_date date not null,
  start_time time,
  end_time time,
  room text,
  published boolean not null default false,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);
create table if not exists public.resources (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  url text not null,
  published boolean not null default false,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);
create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references public.profiles(id) on delete set null,
  action text not null,
  entity text not null,
  entity_id uuid,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create or replace function public.current_app_role()
returns public.app_role language sql stable security definer set search_path = public
as $$ select role from public.profiles where id = auth.uid() $$;
create or replace function public.is_staff()
returns boolean language sql stable security definer set search_path = public
as $$ select coalesce(public.current_app_role() in ('teacher'::public.app_role, 'admin'::public.app_role), false) $$;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, email, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''), new.email, 'student')
  on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

create or replace function public.touch_attendance_updated_at()
returns trigger language plpgsql set search_path = public
as $$ begin new.updated_at = now(); return new; end $$;
drop trigger if exists attendance_records_touch_updated_at on public.attendance_records;
create trigger attendance_records_touch_updated_at before update on public.attendance_records for each row execute procedure public.touch_attendance_updated_at();

alter table public.profiles enable row level security;
alter table public.subjects enable row level security;
alter table public.enrollments enable row level security;
alter table public.attendance_sessions enable row level security;
alter table public.attendance_records enable row level security;
alter table public.notices enable row level security;
alter table public.routines enable row level security;
alter table public.resources enable row level security;
alter table public.audit_logs enable row level security;

-- Profiles: users can read their own profile; staff can read student directory. Role changes are staff-only.
drop policy if exists profiles_read_self_or_staff on public.profiles;
create policy profiles_read_self_or_staff on public.profiles for select to authenticated using (id = auth.uid() or public.is_staff());
drop policy if exists profiles_admin_update on public.profiles;
create policy profiles_admin_update on public.profiles for update to authenticated using (public.current_app_role() = 'admin') with check (public.current_app_role() = 'admin');

-- Subjects are visible to authenticated users; only staff can change them.
drop policy if exists subjects_read_auth on public.subjects;
create policy subjects_read_auth on public.subjects for select to authenticated using (true);
drop policy if exists subjects_staff_all on public.subjects;
create policy subjects_staff_all on public.subjects for all to authenticated using (public.is_staff()) with check (public.is_staff());

-- Enrollment visibility is scoped to self or staff.
drop policy if exists enrollments_read_self_or_staff on public.enrollments;
create policy enrollments_read_self_or_staff on public.enrollments for select to authenticated using (student_id = auth.uid() or public.is_staff());
drop policy if exists enrollments_staff_manage on public.enrollments;
create policy enrollments_staff_manage on public.enrollments for all to authenticated using (public.is_staff()) with check (public.is_staff());

-- A student can only read a session if there is a record for that student.
drop policy if exists attendance_sessions_read_scoped on public.attendance_sessions;
create policy attendance_sessions_read_scoped on public.attendance_sessions for select to authenticated using (
  public.is_staff() or exists (select 1 from public.attendance_records ar where ar.session_id = id and ar.student_id = auth.uid())
);
drop policy if exists attendance_sessions_staff_insert on public.attendance_sessions;
create policy attendance_sessions_staff_insert on public.attendance_sessions for insert to authenticated with check (public.is_staff() and created_by = auth.uid());
drop policy if exists attendance_sessions_staff_update on public.attendance_sessions;
create policy attendance_sessions_staff_update on public.attendance_sessions for update to authenticated using (public.is_staff()) with check (public.is_staff());
drop policy if exists attendance_sessions_admin_delete on public.attendance_sessions;
create policy attendance_sessions_admin_delete on public.attendance_sessions for delete to authenticated using (public.current_app_role() = 'admin');

-- Students may read only their own records; staff can mark and correct attendance.
drop policy if exists attendance_records_read_scoped on public.attendance_records;
create policy attendance_records_read_scoped on public.attendance_records for select to authenticated using (student_id = auth.uid() or public.is_staff());
drop policy if exists attendance_records_staff_insert on public.attendance_records;
create policy attendance_records_staff_insert on public.attendance_records for insert to authenticated with check (public.is_staff() and marked_by = auth.uid());
drop policy if exists attendance_records_staff_update on public.attendance_records;
create policy attendance_records_staff_update on public.attendance_records for update to authenticated using (public.is_staff()) with check (public.is_staff() and marked_by = auth.uid());
drop policy if exists attendance_records_admin_delete on public.attendance_records;
create policy attendance_records_admin_delete on public.attendance_records for delete to authenticated using (public.current_app_role() = 'admin');

-- Published academic content is readable by signed-in users; staff manage it.
drop policy if exists notices_read_published_or_staff on public.notices;
create policy notices_read_published_or_staff on public.notices for select to authenticated using (published or public.is_staff());
drop policy if exists notices_staff_insert on public.notices;
create policy notices_staff_insert on public.notices for insert to authenticated with check (public.is_staff() and created_by = auth.uid());
drop policy if exists notices_staff_update on public.notices;
create policy notices_staff_update on public.notices for update to authenticated using (public.is_staff()) with check (public.is_staff());
drop policy if exists notices_staff_delete on public.notices;
create policy notices_staff_delete on public.notices for delete to authenticated using (public.is_staff());

drop policy if exists routines_read_published_or_staff on public.routines;
create policy routines_read_published_or_staff on public.routines for select to authenticated using (published or public.is_staff());
drop policy if exists routines_staff_manage on public.routines;
create policy routines_staff_manage on public.routines for all to authenticated using (public.is_staff()) with check (public.is_staff());

drop policy if exists resources_read_published_or_staff on public.resources;
create policy resources_read_published_or_staff on public.resources for select to authenticated using (published or public.is_staff());
drop policy if exists resources_staff_manage on public.resources;
create policy resources_staff_manage on public.resources for all to authenticated using (public.is_staff()) with check (public.is_staff());

drop policy if exists audit_logs_admin_read on public.audit_logs;
create policy audit_logs_admin_read on public.audit_logs for select to authenticated using (public.current_app_role() = 'admin');
drop policy if exists audit_logs_staff_insert on public.audit_logs;
create policy audit_logs_staff_insert on public.audit_logs for insert to authenticated with check (public.is_staff() and actor_id = auth.uid());

-- Starter subject rows based on Botany courses; edit as needed for your session.
insert into public.subjects (code, name, semester) values
 ('213001','Microbiology','Botany'),
 ('213003','Mycology','Botany'),
 ('213005','Phycology','Botany'),
 ('213007','Plant Anatomy','Botany')
on conflict (code) do nothing;

-- After the target user has signed up and their profile exists, promote a trusted faculty account:
-- update public.profiles set role = 'admin' where email = 'faculty@example.edu';
-- Or assign teacher role:
-- update public.profiles set role = 'teacher' where email = 'teacher@example.edu';
-- Do not let users choose their own role through the sign-up form.
